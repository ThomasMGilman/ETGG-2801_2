#none at the moment

numStars = 100