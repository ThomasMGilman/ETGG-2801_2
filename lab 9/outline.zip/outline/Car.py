from math3d import *
from sdl2.keycode import *
from ImageTexture2DArray import *
from Program import *
import utils

class Car:
    
    def __init__(self):
        self.body = CarBody()
        self.tire = CarTire()
        
    def update(self, elapsed, keyset):
        if SDLK_w in keyset:
            print("MOVE FORWARD")
        if SDLK_s in keyset:
            print("REVERSE")
        if SDLK_SPACE in keyset:
            print("vroom! Vroom! VROOM!")
        if SDLK_d in keyset:
            print("Tilt!")
        if SDLK_a in keyset:
            print("Untilt!")


    def draw(self):
        
        #placeholder. You will probably want to change this
        Program.setUniform("worldMatrix", mat3.identity() )
        
        
        #draw the car body
        
        #do something with worldmatrix...
        #Program.setUniform("worldMatrix", ??? )
        Program.updateUniforms()
        self.body.draw()
        
        #draw the front tire
        
        #do something else with worldMatrix
        Program.updateUniforms()
        self.tire.draw()
        
        #draw the rear tire
        
        #do something else with worldMatrix
        Program.updateUniforms()
        self.tire.draw()
        

class CarBody:
    def __init__(self):
        self.tex = ImageTexture2DArray("car.png")
        self.vao = utils.makeSquare( 0.5,0.13,False)
    def draw(self):
        glBindVertexArray(self.vao)
        self.tex.bind(0)
        glDrawElements(GL_TRIANGLES,6,GL_UNSIGNED_INT,0)
        
class CarTire:
    def __init__(self):
        self.tex = ImageTexture2DArray("tire.png")
        self.vao = utils.makeSquare( 0.075,0.075,False)
    def draw(self):
        glBindVertexArray(self.vao)
        self.tex.bind(0)
        glDrawElements(GL_TRIANGLES,6,GL_UNSIGNED_INT,0)
  
